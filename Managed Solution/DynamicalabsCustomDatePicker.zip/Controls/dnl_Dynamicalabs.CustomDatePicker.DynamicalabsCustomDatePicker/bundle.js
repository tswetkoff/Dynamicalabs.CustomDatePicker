var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./DynamicalabsCustomDatePicker/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./DynamicalabsCustomDatePicker/index.ts":
/*!***********************************************!*\
  !*** ./DynamicalabsCustomDatePicker/index.ts ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.DynamicalabsCustomDatePicker = void 0;\n\nvar DynamicalabsCustomDatePicker =\n/** @class */\nfunction () {\n  function DynamicalabsCustomDatePicker() {}\n\n  DynamicalabsCustomDatePicker.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this.context = context;\n    this.container = container;\n    this.baseDate = context.parameters.Field.raw && context.parameters.Field.raw.length ? context.parameters.Field.raw : \"\";\n    this.dateFormat = context.parameters.DateFormat.raw && context.parameters.DateFormat.raw.length ? context.parameters.DateFormat.raw : \"\";\n\n    switch (this.dateFormat) {\n      case \"0\":\n        //YYYY-MM\n        this.firstValue = this.baseDate ? this.baseDate.split(\"-\")[1] : \"\";\n        this.secondValue = this.baseDate ? this.baseDate.split(\"-\")[0] : \"\";\n        break;\n\n      case \"1\":\n        //MM/DD\n        this.firstValue = this.baseDate ? this.baseDate.split(\"/\")[0] : \"\";\n        this.secondValue = this.baseDate ? this.baseDate.split(\"/\")[1] : \"\";\n        break;\n    }\n\n    this._notifyOutputChanged = notifyOutputChanged;\n    this.daySelectValues = [\"---\", \"01\", \"02\", \"03\", \"04\", \"05\", \"06\", \"07\", \"08\", \"09\", \"10\", \"11\", \"12\", \"13\", \"14\", \"15\", \"16\", \"17\", \"18\", \"19\", \"20\", \"21\", \"22\", \"23\", \"24\", \"25\", \"26\", \"27\", \"28\", \"29\", \"30\", \"31\"];\n    this.monthSelectValues = {\n      \"---\": \"0\",\n      \"Jan\": \"01\",\n      \"Feb\": \"02\",\n      \"Mar\": \"03\",\n      \"Apr\": \"04\",\n      \"May\": \"05\",\n      \"Jun\": \"06\",\n      \"Jul\": \"07\",\n      \"Aug\": \"08\",\n      \"Sep\": \"09\",\n      \"Oct\": \"10\",\n      \"Nov\": \"11\",\n      \"Dec\": \"12\"\n    };\n    this.yearSelectValues = [\"---\", \"2025\", \"2024\", \"2023\", \"2022\", \"2021\", \"2020\", \"2019\", \"2018\", \"2017\", \"2016\", \"2015\", \"2014\", \"2013\", \"2012\", \"2011\", \"2010\", \"2009\", \"2008\", \"2007\", \"2006\", \"2005\", \"2004\", \"2003\", \"2002\", \"2001\", \"2000\", \"1999\", \"1998\", \"1997\", \"1996\", \"1995\", \"1994\", \"1993\", \"1992\", \"1991\", \"1990\"];\n    this.InitFirstDropdown();\n    this.InitSecondDropdown();\n  };\n\n  DynamicalabsCustomDatePicker.prototype.InitFirstDropdown = function () {\n    var _this = this;\n\n    var context = this;\n    this.firstSelectElement = document.createElement(\"select\");\n    this.firstSelectElement.classList.add(\"dnl-first-select\");\n    Object.keys(this.monthSelectValues).forEach(function (el) {\n      context.firstSelectElement.add(new Option(el));\n    });\n    var monthName = Object.keys(this.monthSelectValues).find(function (el) {\n      return _this.monthSelectValues[el] == _this.firstValue;\n    });\n    this.firstSelectElement.selectedIndex = this.firstValue ? Object.keys(this.monthSelectValues).indexOf(monthName) : 0;\n    this.firstSelectElement.addEventListener(\"change\", this.firstChange.bind(this));\n    this.container.append(this.firstSelectElement);\n  };\n\n  DynamicalabsCustomDatePicker.prototype.InitSecondDropdown = function () {\n    var context = this;\n    this.secondSelectElement = document.createElement(\"select\");\n    this.secondSelectElement.classList.add(\"dnl-second-select\");\n\n    switch (this.dateFormat) {\n      case \"0\":\n        //YYYY-MM\n        this.yearSelectValues.forEach(function (el) {\n          context.secondSelectElement.add(new Option(el));\n        });\n        this.secondSelectElement.selectedIndex = this.secondValue ? this.yearSelectValues.indexOf(this.secondValue) : 0;\n        break;\n\n      case \"1\":\n        //MM/DD\n        var currentMonth = this.firstValue && this.firstValue[0] == \"0\" && this.firstValue.length > 1 ? this.firstValue.substring(1) : this.firstValue == \"---\" || !this.firstValue ? \"1\" : this.firstValue;\n        var currentYear = new Date().getFullYear();\n        var daysInMonth = this.getDaysInMonth(parseInt(currentMonth, 10), currentYear);\n\n        for (var i = 0; i <= daysInMonth; i++) {\n          context.secondSelectElement.add(new Option(this.daySelectValues[i]));\n        }\n\n        this.secondSelectElement.selectedIndex = this.secondValue ? this.daySelectValues.indexOf(this.secondValue) : 0;\n        break;\n    }\n\n    this.secondSelectElement.addEventListener(\"change\", this.secondChange.bind(this));\n    this.container.append(this.secondSelectElement);\n  };\n\n  DynamicalabsCustomDatePicker.prototype.firstChange = function () {\n    this.firstValue = this.firstSelectElement[this.firstSelectElement.selectedIndex].innerText;\n    this.firstValue = this.monthSelectValues[this.firstValue];\n\n    switch (this.dateFormat) {\n      case \"1\":\n        //MM/DD\n        var currentMonth = this.firstValue && this.firstValue[0] == \"0\" && this.firstValue.length > 1 ? this.firstValue.substring(1) : this.firstValue == \"---\" || !this.firstValue ? \"1\" : this.firstValue;\n        var currentYear = new Date().getFullYear();\n        var daysInMonth_1 = this.getDaysInMonth(parseInt(currentMonth, 10), currentYear);\n        var daysArray = this.daySelectValues.filter(function (el) {\n          return el !== \"---\" && parseInt(el, 10) <= daysInMonth_1;\n        });\n        this.clearAllOptions();\n\n        for (var i = 0; i <= daysInMonth_1; i++) {\n          this.secondSelectElement.add(new Option(this.daySelectValues[i]));\n        }\n\n        if (this.secondValue && this.secondValue !== \"0\") {\n          this.secondSelectElement.selectedIndex = this.secondValue && daysArray.includes(this.secondValue) ? daysArray.indexOf(this.secondValue) + 1 : daysArray.length;\n          this.secondChange();\n        }\n\n        break;\n    }\n\n    this._notifyOutputChanged();\n  };\n\n  DynamicalabsCustomDatePicker.prototype.secondChange = function () {\n    this.secondValue = this.secondSelectElement[this.secondSelectElement.selectedIndex].innerText.replace(\"---\", \"0\");\n\n    this._notifyOutputChanged();\n  };\n\n  DynamicalabsCustomDatePicker.prototype.getDaysInMonth = function (month, year) {\n    return new Date(year, month, 0).getDate();\n  };\n\n  DynamicalabsCustomDatePicker.prototype.clearAllOptions = function () {\n    var i = 0;\n    var selectLength = this.secondSelectElement.options.length - 1;\n\n    for (i = selectLength; i >= 0; i--) {\n      this.secondSelectElement.remove(i);\n    }\n  };\n\n  DynamicalabsCustomDatePicker.prototype.updateView = function (context) {\n    this.baseDate = context.parameters.Field.raw ? context.parameters.Field.raw : \"\";\n  };\n\n  DynamicalabsCustomDatePicker.prototype.getOutputs = function () {\n    var format = \"\";\n\n    switch (this.dateFormat) {\n      case \"0\":\n        //YYYY-MM\n        format = this.secondValue + \"-\" + this.firstValue;\n        break;\n\n      case \"1\":\n        //MM/DD\n        format = this.firstValue + \"/\" + this.secondValue;\n    }\n\n    return {\n      Field: (!this.secondValue || this.secondValue === \"0\") && (!this.firstValue || this.firstValue === \"0\") ? undefined : format\n    };\n  };\n\n  DynamicalabsCustomDatePicker.prototype.destroy = function () {};\n\n  return DynamicalabsCustomDatePicker;\n}();\n\nexports.DynamicalabsCustomDatePicker = DynamicalabsCustomDatePicker;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DynamicalabsCustomDatePicker/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Dynamicalabs.CustomDatePicker.DynamicalabsCustomDatePicker', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DynamicalabsCustomDatePicker);
} else {
	var Dynamicalabs = Dynamicalabs || {};
	Dynamicalabs.CustomDatePicker = Dynamicalabs.CustomDatePicker || {};
	Dynamicalabs.CustomDatePicker.DynamicalabsCustomDatePicker = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DynamicalabsCustomDatePicker;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}